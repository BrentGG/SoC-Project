#include <stdio.h>
#include <unistd.h>
#include "platform.h"
#include "xil_printf.h"
#include "xbasic_types.h"
#include "stdio.h"
#include "xiic_l.h"

#define DS1086L_IIC_ADDRESS 0x58

unsigned int unDacValue=0;
unsigned int unPrescalarValue=0;
unsigned int unJitterValue=0;
int nOffsetDelta=0;

int max_DS1086_get_dac(u32 unPeripheralAddressI2C, unsigned int *unDacValue);
int max_DS1086_get_prescalar(u32 unPeripheralAddressI2C, unsigned int *unPreScalarValue);
int max_DS1086_get_jitter(u32 unPeripheralAddressI2C, unsigned int *unJitterValue);
int max_DS1086_get_offset_delta(u32 unPeripheralAddressI2C,  int *nOffsetDelta);

int max_DS1086_set_dac(u32 unPeripheralAddressI2C, unsigned int unDacValue);
int max_DS1086_set_prescalar(u32 unPeripheralAddressI2C, unsigned int unPreScalarValue);
int max_DS1086_set_jitter(u32 unPeripheralAddressI2C, unsigned int unJitterValue);
int max_DS1086_set_offset_delta(u32 unPeripheralAddressI2C,  int nOffsetDelta);

int main()
{
    init_platform();

    print("Successfully ran DS1086L application");

    int dacValue = 100;
    int prescaleValue = 1;

    while (1) {
		int retVal = 0;
		retVal = max_DS1086_set_dac(XPAR_IIC_0_BASEADDR,dacValue);
		printf("%d\n", retVal);
		usleep(1000 * 1000);
		retVal = max_DS1086_set_prescalar(XPAR_IIC_0_BASEADDR,prescaleValue);
		printf("%d\n", retVal);
		usleep(1000 * 1000);
		retVal = max_DS1086_set_jitter(XPAR_IIC_0_BASEADDR,50100);
		printf("%d\n", retVal);
		usleep(1000 * 1000);
		retVal = max_DS1086_set_offset_delta(XPAR_IIC_0_BASEADDR,10);
		printf("%d\n", retVal);
		usleep(1000 * 1000);

		max_DS1086_get_dac(XPAR_IIC_0_BASEADDR, &unDacValue);
		max_DS1086_get_prescalar(XPAR_IIC_0_BASEADDR, &unPrescalarValue);
		max_DS1086_get_jitter(XPAR_IIC_0_BASEADDR, &unJitterValue);
		max_DS1086_get_offset_delta(XPAR_IIC_0_BASEADDR,&nOffsetDelta);

		printf("Last DAC reading = %d (decimal)\n",unDacValue);
		printf("Last Jitter Value = %d (decimal)\n",unJitterValue);
		printf("Last Prescalar Value = %d (decimal)\n",unPrescalarValue);
		printf("Last Offset Delta Value = %d (decimal)\n\n",nOffsetDelta);

		dacValue = dacValue == 100 ? 1000 : 100;
		prescaleValue = prescaleValue == 1 ? 256 : 1;

		usleep(2000 * 1000);
    }

    cleanup_platform();
    return 0;
}

int max_DS1086_get_dac(u32 unPeripheralAddressI2C, unsigned int *unDacValue)
/**
* \brief       Retrieves the present value of the DAC which drives the DS1086 VCO.
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[out]  *unDacValue               - DAC value from DS1086 is stored at unDacValue
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	unsigned int unTemp;
	int nReturnVal=TRUE;

	auchTxBuffer[0] = 0x08;  // 10-bit DAC (for VCO) register is 0x08
	auchTxBuffer[1] = 0x00;
	auchTxBuffer[2] = 0x00;

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;

	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
			(u8 *)&auchRxBuffer, 2, XIIC_STOP);
	if(nByteCount!=2)
		nReturnVal=FALSE;

	if(nReturnVal==TRUE)
	{
		unTemp = auchRxBuffer[0];
		unTemp = unTemp << 2;
		unTemp |= ((auchRxBuffer[1] & 0xC0) >> 6);
		*unDacValue = unTemp;
	}

	return(nReturnVal);
}

int max_DS1086_get_prescalar(u32 unPeripheralAddressI2C, unsigned int *unPreScalarValue)
/**
* \brief       Retrieve the 4-bit prescaler value in the DS1086.
* \par         Details
*              The DS1086L output is prescaled (divided down) by a value between 2^0 (=1) and 2^8 (=256).  The
*              divide ratio is set by the prescaler register.  This is a 4-bit number, although values greater
*              than 8 are recognized as 8.
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[out]  *unPreScalarValue         - the 4-bit prescaler value retrived is stored at to set
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	unsigned int unTemp;
	int nReturnVal=TRUE;

	// The prescalar 16-bit word carries more data than just the prescalar value (see datasheet)
	// so we must read the prescalar value and then modify the bits to change the P3..0 bits
	auchTxBuffer[0] = 0x02;  // Prescalar register is 0x02
	auchTxBuffer[1] = 0x00;  // NULL
	auchTxBuffer[2] = 0x00;  // NULL

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;
	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchRxBuffer, 2, XIIC_STOP);
	if(nByteCount!=2)
		nReturnVal=FALSE;

	// If the read was successful, parse the bits and set the value @ *unPrescalarValue
	if(nReturnVal==TRUE)
	{
		unTemp = (auchRxBuffer[0] & 0x03);
		unTemp = unTemp << 2;
		unTemp |= ((auchRxBuffer[1] & 0xC0) >> 6);
		*unPreScalarValue = unTemp;
	}
	return(nReturnVal);
}

int max_DS1086_get_jitter(u32 unPeripheralAddressI2C, unsigned int *unJitterValue)
/**
* \brief       Retrieve the 5-bit jitter register value in the DS1086.
* \par         Details
*              This function returns the 5-bit value for the jitter setting.  This number contains the following bits:
* \n           JS[4:3] = Jitter rate,  JS[2:0] = Jitter percentage
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[out]  *unJitterValue            - the 5-bit jitter value retrived is stored to unJitterValue
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	unsigned int unTemp;
	int nReturnVal=TRUE;

	// The prescalar 16-bit word carries more data than just the prescalar value (see datasheet)
	// so we must read the prescalar value and then modify the bits to change the P3..0 bits
	auchTxBuffer[0] = 0x02;  // Prescalar register is 0x02
	auchTxBuffer[1] = 0x00;  // NULL
	auchTxBuffer[2] = 0x00;  // NULL

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;

	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchRxBuffer, 2, XIIC_STOP);
	if(nByteCount!=2)
		nReturnVal=FALSE;

	// If the read was successful, parse the bits and set the value @ *unJitterValue
	if(nReturnVal==TRUE)
	{
		unTemp = (auchRxBuffer[0] & 0xF8);  // five MSBs are JS[4:0]
		unTemp = unTemp >> 3;
		*unJitterValue = unTemp;
	}
	return(nReturnVal);
}

int max_DS1086_get_offset_delta(u32 unPeripheralAddressI2C,  int *nOffsetDelta)
/**
* \brief       Retrieve the 5-bit offset/delta register value in the DS1086.
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[out]  *nOffsetDelta             - the 5-bit offset value retrived is stored to nOffsetDelta
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	int nTempRange=0;
	int nTempOffset=0;
	int nTempOffsetDelta=0;
	int nReturnVal=TRUE;

	// Read the Range Register (factory default)
	auchTxBuffer[0] = 0x37;  // Range register is 0x37
	auchTxBuffer[1] = 0x00;  // NULL
	auchTxBuffer[2] = 0x00;  // NULL

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;
	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchRxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;

	// If the read was successful, read the offset register
	if(nReturnVal==TRUE)
	{
		nTempRange = auchRxBuffer[0] & 0x1F; // LSB 5 bits

		// Read the Offset Register
		auchTxBuffer[0] = 0x0E;  // Offset register is 0x0E
		auchTxBuffer[1] = 0x00;  // NULL
		auchTxBuffer[2] = 0x00;  // NULL

		nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
				(u8 *)&auchTxBuffer, 1, XIIC_STOP);
		if(nByteCount!=1)
			nReturnVal=FALSE;
		nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
				(u8 *)&auchRxBuffer, 1, XIIC_STOP);
		if(nByteCount!=1)
			nReturnVal=FALSE;

		// If the offset register read was successful, subtract the two values to get the offset value
		if(nReturnVal==TRUE)
		{
			nTempOffset=auchRxBuffer[0] & 0x1F;
			nTempOffsetDelta = nTempOffset - nTempRange;
			*nOffsetDelta = nTempOffsetDelta;
		}
	}
	return(nReturnVal);
}

int max_DS1086_set_dac(u32 unPeripheralAddressI2C, unsigned int unDacValue)
/**
* \brief       Set the DAC which drives the DS1086 VCO.
* \par         Details
*              The DAC within the DS1086 changes the output frequency by approximately 5kHz per step.
* \n           JS[4:3] = Jitter rate,  JS[2:0] = Jitter percentage*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[in]   unDacValue                - 10-bit value to store to the DAC register
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	int nByteCount=0;
	unsigned int unTemp;
	unsigned int unTempMSB;
	unsigned int unTempLSB;
	int nReturnVal=TRUE;

	unTemp=unDacValue;

	if(unTemp>1023)
		nReturnVal=FALSE;
	else
	{
		// Convert the value to the 10-bit value used in the 1086
		unTempMSB = (unTemp & 0x03FC);
		unTempMSB = unTempMSB >> 2;
		unTempLSB = (unTemp & 0x03);
		unTempLSB = unTempLSB << 6;

		// Write the new value to the DAC register
		auchTxBuffer[0] = 0x08;  // 10-bit DAC (for VCO) register is 0x02
		auchTxBuffer[1] = (u8)unTempMSB;  // Set upper 8 bits of DAC
		auchTxBuffer[2] = (u8)unTempLSB;  // Set lower 2 bits of DAC
		nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
			(u8 *)&auchTxBuffer, 3, XIIC_STOP);
		if(nByteCount!=3)
			nReturnVal=FALSE;
	}

	return(nReturnVal);
}

int max_DS1086_set_prescalar(u32 unPeripheralAddressI2C, unsigned int unPreScalarValue)
/**
* \brief       Set the 4-bit prescaler value in the DS1086.
* \par         Details
*              The DS1086L output is prescaled (divided down) by a value between 2^0 (=1) and 2^8 (=256).  The
*              divide ratio is set by the prescaler register.  This is a 4-bit number, although values greater
*              than 8 are recognized as 8.
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[in]   unPreScalarValue          - 4-bit prescaler value to set
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	unsigned int unTemp;
	unsigned int unTempMSB;
	unsigned int unTempLSB;
	int nReturnVal=TRUE;

	// The prescalar 16-bit word carries more data than just the prescalar value (see datasheet)
	// so we must read the prescalar value and then modify the bits to change the P3..0 bits
	auchTxBuffer[0] = 0x02;  // Prescalar register is 0x02
	auchTxBuffer[1] = 0x00;  // NULL
	auchTxBuffer[2] = 0x00;  // NULL

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;
	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchRxBuffer, 2, XIIC_STOP);
	if(nByteCount!=2)
		nReturnVal=FALSE;

	// If the read of the prescalar register was successful, set the new value
	if(nReturnVal==TRUE)
	{
		unTempMSB = auchRxBuffer[0];
		unTempLSB = auchRxBuffer[1];

		// Zero the old bits of the pre-scalar value
		unTempMSB &= 0xFC;
		unTempLSB &= 0x3F;

		// PreScalar Value is capped at 8 (per datasheet)
		unTemp = unPreScalarValue;
		if(unTemp >= 8)
			unTemp=8;

		// Set the new bits of the pre-scalar value
		if((unTemp & 0x08)==0x08)  	// bit 3
			unTempMSB |= 0x02;
		if((unTemp & 0x04)==0x04)
			unTempMSB |= 0x01;
		if((unTemp & 0x02)==0x02)
			unTempLSB |= 0x80;
		if((unTemp & 0x01)==0x01) 	// bit 0
			unTempLSB |= 0x40;

		// Write the bits back to the pre-scalar register
		auchTxBuffer[0] = 0x02;  // Prescalar register is 0x02
		auchTxBuffer[1] = (u8)unTempMSB;
		auchTxBuffer[2] = (u8)unTempLSB;
		nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
			(u8 *)&auchTxBuffer, 3, XIIC_STOP);
		if(nByteCount!=3)
			nReturnVal=FALSE;
	}

	return(nReturnVal);
}

int max_DS1086_set_jitter(u32 unPeripheralAddressI2C, unsigned int unJitterValue)
/**
* \brief       Set the 5-bit jitter register value in the DS1086.
* \par         Details
*              This function sets the 5-bit value for the jitter setting.  This number contains the following bits:
* \n           JS[4:3] = Jitter rate,  JS[2:0] = Jitter percentage
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[in]   unJitterValue             - the 5-bit jitter value to set
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	unsigned int unTempMSB;
	unsigned int unTempLSB;
	int nReturnVal=TRUE;

	// The prescalar 16-bit word carries more data than just the jitter JS[4:0] value (see datasheet)
	// so we must read the prescalar value and then modify the bits to change the JS[4:0] bits
	auchTxBuffer[0] = 0x02;  // Prescalar register is 0x02
	auchTxBuffer[1] = 0x00;  // NULL
	auchTxBuffer[2] = 0x00;  // NULL

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;

	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchRxBuffer, 2, XIIC_STOP);
	if(nByteCount!=2)
		nReturnVal=FALSE;

	// If the read of the prescalar register was successful, set the new jitter value
	if(nReturnVal==TRUE)
	{
		unTempMSB = auchRxBuffer[0];
		unTempLSB = auchRxBuffer[1];

		// Zero the old bits of the jitter value (5 MSBs in the MSB byte)
		unTempMSB &= 0x07;

		// Set the new bits of the jitter value
		if((unJitterValue & 0x10)==0x10)  	// bit 4
			unTempMSB |= 0x80;
		if((unJitterValue & 0x08)==0x08)
			unTempMSB |= 0x40;
		if((unJitterValue & 0x04)==0x04)
			unTempMSB |= 0x20;
		if((unJitterValue & 0x02)==0x02)
			unTempMSB |= 0x10;
		if((unJitterValue & 0x01)==0x01) 	// bit 0
			unTempMSB |= 0x08;

		// Write the bits back to the pre-scalar register
		auchTxBuffer[0] = 0x02;  // Prescalar register is 0x02
		auchTxBuffer[1] = (u8)unTempMSB;
		auchTxBuffer[2] = (u8)unTempLSB;
		nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
			(u8 *)&auchTxBuffer, 3, XIIC_STOP);
		if(nByteCount!=3)
			nReturnVal=FALSE;
	}

	return(nReturnVal);
}

// This function sets the value of the offset/delta register in the DS1086
// The offset allows the Master Oscillator Base Frequency to be set in a range from ~61.4MHz to ~122.8MHz
// The offset value needs to be programmed wrt to a factory calibrated RANGE setting (register 0x37)
// So, this function reads the RANGE setting, and then +/- 6 before setting the OFFSET register (0x0E) with the value
int max_DS1086_set_offset_delta(u32 unPeripheralAddressI2C,  int nOffsetDelta)
/**
* \brief       Set the 5-bit offset register value in the DS1086.
* \par         Details
*              The offset allows the Master Oscillator Base Frequency to be set in a range from ~61.4MHz to ~122.8MHz.
*              The offset value needs to be programmed wrt to a factory calibrated RANGE setting (register 0x37).
*              This function reads the RANGE setting, and then +/- 6 before setting the OFFSET register (0x0E) with the value
*
* \param[in]   unPeripheralAddressI2C    - address of the I2C peripheral in Microblaze memory map
* \param[out]  nOffsetDelta              - the 5-bit offset value to set
*
* \retval      TRUE if operation succeeded
*/
{
	u8 auchTxBuffer[3];
	u8 auchRxBuffer[3];
	int nByteCount=0;
	int nTemp;
	int nTempOffsetDelta;
	int nReturnVal=TRUE;

	// Read the Range Register
	auchTxBuffer[0] = 0x37;  // Prescalar register is 0x02
	auchTxBuffer[1] = 0x00;  // NULL
	auchTxBuffer[2] = 0x00;  // NULL

	nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchTxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;

	nByteCount = XIic_Recv(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
		(u8 *)&auchRxBuffer, 1, XIIC_STOP);
	if(nByteCount!=1)
		nReturnVal=FALSE;

	// If the read was successful, parse the bits and set the value @ *unPrescalarValue
	if(nReturnVal==TRUE)
	{
		nTemp = (auchRxBuffer[0] & 0x1F);  // mask off the upper 3 bits (they are unused but always read as one)
		nTempOffsetDelta = nOffsetDelta;

		// Cap the offset delta at +/-6
		if(nTempOffsetDelta < -6)
			nTempOffsetDelta=-6;
		else if(nTempOffsetDelta > 6)
			nTempOffsetDelta=6;

		// Calculate the offset Delta value (and then make sure it is a positive number)
		nTemp = nTemp + nTempOffsetDelta;
		if(nTemp<0)
			nTemp=0;

		// Write the offset register
		auchTxBuffer[0] = 0x0E;  // OFFSET register is 0x0E
		auchTxBuffer[1] = (u8)nTemp;

		nByteCount = XIic_Send(unPeripheralAddressI2C, DS1086L_IIC_ADDRESS,
			(u8 *)&auchTxBuffer, 2, XIIC_STOP);
		if(nByteCount!=2)
			nReturnVal=FALSE;
	}
	return(nReturnVal);
}
